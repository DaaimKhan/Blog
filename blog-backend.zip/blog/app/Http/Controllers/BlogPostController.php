<?php

namespace App\Http\Controllers;

use App\Models\BlogPost;
use Illuminate\Http\Request;

class BlogPostController extends Controller
{
   public function index()
    {
        try {
            $blogPosts = BlogPost::paginate(10);
            return response()->json($blogPosts);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Unable to fetch blog posts'], 500);
        }
    }

    public function show($id)
    {
        try {
            $blogPost = BlogPost::findOrFail($id);
            return response()->json($blogPost);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Blog post not found'], 404);
        }
    }

    public function store(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'title' => 'required|string|max:255',
                'content' => 'required|string',
                'author' => 'required|string|max:255',
                'publication_date' => 'required|date',
            ]);
            
            $blogPost = BlogPost::create($validatedData);
            return response()->json($blogPost, 201);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Unable to create the blog post'], 500);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $validatedData = $request->validate([
                'title' => 'required|string|max:255',
                'content' => 'required|string',
                'author' => 'required|string|max:255',
                'publication_date' => 'required|date',
            ]);
            
            $blogPost = BlogPost::findOrFail($id);
            $blogPost->update($validatedData);
            return response()->json($blogPost);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Unable to update the blog post'], 500);
        }
    }

    public function destroy($id)
    {
        try {
            $blogPost = BlogPost::findOrFail($id);
            $blogPost->delete();
            return response()->json(null, 204);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Unable to delete the blog post'], 500);
        }
    }
}   
